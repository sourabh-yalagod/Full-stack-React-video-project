export const Options = {
  httpOnly: false,
  secure: true,
};
